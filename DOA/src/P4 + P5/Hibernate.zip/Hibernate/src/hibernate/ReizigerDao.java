package hibernate;

public interface ReizigerDao extends BaseDao<Reiziger> {

}
