package hibernate;

public interface OVChipkaartDao extends BaseDao<OVChipkaart> {


}
