//package P1;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//
//public class DBConnect {
//
//    private static final String DB_DRIV = "oracle.jdbc.driver.OracleDriver";
//    private static final String DB_URL = "jdbc:oracle:thin:@//localhost:1521/xepdb1";
//    private static final String DB_USER = "groax";
//    private static final String DB_PASS = "Honden123!";
////    private static Connection conn;
//
//    public static void main(String[] args) {
//
//        try {
//            Class.forName(DB_DRIV);
//
//            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
//            conn.prepareStatement("SELECT * from MEDEWERKERS").execute();
//        }
//        catch (SQLException err) {
//            System.out.println(err);
//        }
//    }
//}