create trigger T_AFDELINGEN_ID
    before insert
    on AFDELINGEN
    for each row
BEGIN
  if(:new.ANR is null) then
  SELECT S_AFDELINGEN.nextval
  INTO :new.ANR
  FROM dual;
  end if;
END;
/

